package service;

import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public interface Inventariable<T extends CSVSerializable> {
    
    void agregar(T item);
    
    T obtener(int indice);
    
    void eliminar(int indice);
    
    List<T> filtrar(Predicate<T> predicado);
    
    void ordenar();
    
    void ordenar(Comparator<T> comparador);
    
    void serializar(String path);
    
    void deserializar(String path);
    
    void guardarCSV(String path);
    
    void cargarCSV(String path, Function<String, T> funcion);
    
    void paraCadaElemento(Consumer<T> consumer);
    
}