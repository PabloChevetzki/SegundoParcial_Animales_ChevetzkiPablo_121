package service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class Zoologico<T extends CSVSerializable> implements Inventariable<T> {

    List<T> lista = new ArrayList<>();
    
    @Override
    public void agregar(T item) {
        lista.add(item);
    }

    @Override
    public T obtener(int indice) {
        return lista.get(indice);
    }

    @Override
    public void eliminar(int indice) {
        lista.remove(indice);
    }

    @Override
    public List<T> filtrar(Predicate<T> predicado) {
        
        List<T> toReturn = new ArrayList<>();
        for(T item:lista) {
            if(predicado.test(item)) {
                toReturn.add(item);
            }
        }    
        return toReturn;    
    }

    @Override
    public void ordenar() {
        ordenar((Comparator<T>) Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<T> comparador) {
        lista.sort(comparador);
    }

    @Override
    public void serializar(String path) {

        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            
            salida.writeObject(lista);
            
        } catch (IOException ex) {
            System.out.println(ex.getMessage()); 
        }
    }

    @Override
    public void deserializar(String path) {
        
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))) {
            
            lista = (List<T>) input.readObject();
            
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage()); 
        }
    }

    @Override
    public void guardarCSV(String path) {
       
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            bw.write("id,nombre,especie,alimentacion\n");
            for(T item: lista) {
                bw.write(item.toCSV() + "\n");
            }
 
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            throw new RuntimeException("Error en archivo");
        }      
    }

    @Override
    public void cargarCSV(String path, Function<String, T> funcion) {
        lista.clear();
        try (BufferedReader bf = new BufferedReader(new FileReader(path))) {
            String linea;
            bf.readLine();
            while ((linea = bf.readLine()) != null) {
                lista.add(funcion.apply(linea));
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            throw new RuntimeException("Error en archivo");
        }
    }

    @Override
    public void paraCadaElemento(Consumer<T> consumer) {
        for(T item: lista) {
            consumer.accept(item);
        }
    }
}